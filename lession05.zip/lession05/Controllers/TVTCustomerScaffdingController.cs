﻿using lession05.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace lession05.Controllers
{
    public class TVTCustomerScaffDingController : Controller
    {
        private static List<TvtCustomer> listCustomer = new List<TvtCustomer>()
        {
            new TvtCustomer()
                {
                    CustomerId = 1,
                FirsName = " ta van thang",
                LasName = "thang 1",
                Address = "k22cntt3",
                YesrOfBirth = 2004
                },
                new TvtCustomer()
                {
                  CustomerId = 2,
                FirsName = " ta van thang",
                LasName = "thang 2",
                Address = "k22cntt3",
                YesrOfBirth = 2004
                },
                new TvtCustomer()
                {
                 CustomerId = 3,
                FirsName = " ta van thang",
                LasName = "thang 3",
                Address = "k22cntt3",
                YesrOfBirth = 2004
                },
                new TvtCustomer()
                {
               CustomerId = 4,
                FirsName = " ta van thang",
                LasName = "thang 4",
                Address = "k22cntt3",
                YesrOfBirth = 2004
                },
            };
        // GET: TVTCustomerScaffDing
        // listCustomer
        public ActionResult Index()
        {
            return View(listCustomer);
        }
        [HttpGet]
        public ActionResult TVTCreate()
        {
            var model = new TvtCustomer();
            return View(model);
        }
        [HttpPost]
        public ActionResult TVTCreate(TvtCustomer model)
        {
            listCustomer.Add(model);
            //return View();
            return RedirectToAction("Index");
        }
        public ActionResult TVTEdit(int id)
        {
            var customer = listCustomer.FirstOrDefault(x => x.CustomerId == id);
            return View(customer);
        }
    }
}