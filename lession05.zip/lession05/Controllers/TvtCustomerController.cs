﻿using lession05.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace lession05.Controllers
{
    public class TvtCustomerController : Controller
    {
        // GET: TvtCustomer
        public ActionResult Index()
        {
            return View();
        }
        // action: TvtCustomerDetail
        public ActionResult tvtCustomerDetail()
        {
            // tao doi tuong du lieu
            var customer = new TvtCustomer()
            {
                CustomerId = 1,
                FirsName = " ta van thang",
                LasName = "thang",
                Address = "k22cntt3",
                YesrOfBirth = 2004
            };
            ViewBag.CustomerId = customer;
            return View();
        }
        public ActionResult TVTlistCustomer()
        {
            var list = new List<TvtCustomer>()
            {
                new TvtCustomer()
                {
                    CustomerId = 1,
                FirsName = " ta van thang",
                LasName = "thang 1",
                Address = "k22cntt3",
                YesrOfBirth = 2004
                },
                new TvtCustomer()
                {
                  CustomerId = 2,
                FirsName = " ta van thang",
                LasName = "thang 2",
                Address = "k22cntt3",
                YesrOfBirth = 2004
                },
                new TvtCustomer()
                {
                 CustomerId = 3,
                FirsName = " ta van thang",
                LasName = "thang 3",
                Address = "k22cntt3",
                YesrOfBirth = 2004
                },
                new TvtCustomer()
                {
               CustomerId = 4,
                FirsName = " ta van thang",
                LasName = "thang 4",
                Address = "k22cntt3",
                YesrOfBirth = 2004
                },
            };
            ViewBag.list = list;
            return View();
        }
    }
}