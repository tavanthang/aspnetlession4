﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace lession05.Models
{
    public class TvtCustomer
    {
        public int CustomerId { get; set; }
        public string FirsName { get; set; }
        public string LasName { get; set; }
        public string Address { get; set; }
        public int YesrOfBirth { get; set }
    }
}